class CreateHistory {
  String? Poke_name;
  String? Image_directory;
  double? total_price;
  int? quantity;
  CreateHistory(
      this.Poke_name, this.Image_directory, this.total_price, this.quantity);
}
